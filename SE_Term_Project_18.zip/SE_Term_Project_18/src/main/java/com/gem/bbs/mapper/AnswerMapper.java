package com.gem.bbs.mapper;

import com.gem.bbs.entity.Answer;

import java.util.List;

/**
 * @Author: zhouzhixian
 * @WX: 20210225
 * @Date: 2024/5/20 13:14
 * @Description: 回复接口
 */
public interface AnswerMapper {
    /**
     * 根据问题主键获取回复记录 Get reply history based on the primary key of the question
     */
    List<Answer> selectListByQuestionId(Integer id);

    /**
     * 保存回复 Save Reply
     */
    void insertAnswer(Answer answer);
}
