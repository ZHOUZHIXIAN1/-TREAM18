package com.gem.bbs.controller;

import com.gem.bbs.entity.Answer;
import com.gem.bbs.entity.Question;
import com.gem.bbs.service.AnswerService;
import com.gem.bbs.service.QuestionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpSession;
import java.util.List;

/**
 * @Author: zhouzhixian
 * @WX: 20210225
 * @Date: 2024/5/20 13:14
 * @Description: 问题控制器
 */
@Controller
@RequestMapping("/ques")
public class QuestionController {
    @Autowired
    private QuestionService questionService;
    @Autowired
    private AnswerService answerService;

    @RequestMapping("/form")
    public String form() {
        return "questionForm";
    }

    @RequestMapping("/save")
    public String save(Question question, HttpSession session) {
        questionService.save(question, session);
        return "redirect:/index";
    }

    /**
     * Get the details of the problem
     */
    @RequestMapping("/detail")
    public String detail(Integer id, Model model) {
        Question question = questionService.selectOne(id);
        //Get a response to this question
        List<Answer> answerList = answerService.findListByQuestionId(id);

        model.addAttribute("question",question);
        model.addAttribute("answerList",answerList);
        return "questionDetail";
    }
}
