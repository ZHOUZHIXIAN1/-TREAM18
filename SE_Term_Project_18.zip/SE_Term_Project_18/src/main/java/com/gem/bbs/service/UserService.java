package com.gem.bbs.service;

import com.gem.bbs.entity.User;

import javax.servlet.http.HttpSession;

/**
 * @Author: zhouzhixian
 * @WX: 20210225
 * @Date: 2024/5/20 13:14
 * @Description:
 */
public interface UserService {
    /**
     * 注册用户 Registered users
     */
    void register(User user);

    /**
     * 用户登录 user login
     */
    String login(String loginname,String password,HttpSession session);
}
