package com.gem.bbs.controller;

import com.gem.bbs.entity.Answer;
import com.gem.bbs.service.AnswerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpSession;

/**
 * @Author: zhouzhixian
 * @WX: 20210225
 * @Date: 2024/5/20 13:14
 * @Description: 回复控制器
 */
@Controller
@RequestMapping("/ans")
public class AnswerController {
    @Autowired
    private AnswerService answerService;

    @RequestMapping("/save")
    public String save(Answer answer, HttpSession session) {
        answerService.save(answer,session);
        return "redirect:/ques/detail?id=" + answer.getQuestionId();
    }
}
