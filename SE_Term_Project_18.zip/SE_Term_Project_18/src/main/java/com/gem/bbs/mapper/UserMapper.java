package com.gem.bbs.mapper;

import com.gem.bbs.entity.User;

/**
 * @Author: zhouzhixian
 * @WX: 20210225
 * @Date: 2024/5/20 13:14
 * @Description: 用户接口 User interface
 */
public interface UserMapper {
    //注册，即保存用户 Register, that is, save the user
    void insertUser(User user);

    //登录，根据用户名查询用户 Login, query the user according to the user name
    User findUserByLoginname(String loginname);
}
