package com.gem.bbs.service;

import com.gem.bbs.entity.Question;

import javax.servlet.http.HttpSession;
import java.util.List;

/**
 * @Author: zhouzhixian
 * @WX: 20210225
 * @Date: 2024/5/20 13:14
 * @Description:
 */
public interface QuestionService {

    /**
     * 根据主键查询问题 根据主键查询问题 According to the main key query questions of main key query questions
     */
    Question selectOne(Integer id);
    /**
     * 保存问题 Problems of preservation
     */
    void save(Question question,HttpSession session);

    /**
     * 获取总页数 Total number of pages
     */
    Integer getTotalPage(Integer pageCount,String title);

    /**
     * 获取记录数 Number of records obtained
     */
    List<Question> findAll(Integer currentPage, Integer pageCount,String title);
}
