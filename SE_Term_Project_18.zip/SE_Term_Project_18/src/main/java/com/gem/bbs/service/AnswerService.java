package com.gem.bbs.service;

import com.gem.bbs.entity.Answer;

import javax.servlet.http.HttpSession;
import java.util.List;

/**
 * @Author: zhouzhixian
 * @WX: 20210225
 * @Date: 2024/5/20 13:14
 * @Description: 回复服务层接口
 */
public interface AnswerService {
    /**
     * 根据问题id查询回复列表 Query reply list based on question id
     */
    List<Answer> findListByQuestionId(Integer id);

    /**
     * 保存问题 Problems of preservation
     */
    void save(Answer answer,HttpSession session);
}
