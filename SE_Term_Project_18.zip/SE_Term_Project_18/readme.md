## 1. 프로젝트 소개
SE_Term_Project_18

## 2. 기능 소개

### 2.1 계정 추가（已完成）

### 2.2 이슈 브라우즈 및 검색 (예를 들어 assignee 값, 이슈 상태, reporter 값 등)

### 2.3 이슈 등록 (꼭 채워야하는 필드는 Title, Description. reporter 필드는 이슈를 등록한 계정으로, reported date는 등록한 날짜와 시간으로 자동으로 채워짐)

### 2.4 이슈 코멘트 추가

### 2.5 이슈 상세 정보 확인 (이슈의각 필드와 코멘트 history 확인 가능)

### 2.6 이슈 배정을 포함한 이슈 상태 변경

### 2.7 이슈 통계 분석(일/월 별 이슈 발생 횟수 및 트랜드 등 표시)

## 3、운영 및 배치
프로젝트 실행 접근 경로: http://localhost:8080/bbs/index


## 4、github.com
https://github.com/ZHOUZHIXIAN1/-TREAM18